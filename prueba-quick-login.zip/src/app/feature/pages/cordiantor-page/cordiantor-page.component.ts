import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cordiantor-page',
  templateUrl: './cordiantor-page.component.html',
  styleUrls: ['./cordiantor-page.component.css']
})
export class CordiantorPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
