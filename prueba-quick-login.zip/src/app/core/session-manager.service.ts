import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class SessionManagerService {

  constructor(private router:Router) { }

  public login(username:string):boolean{
   
    if(this.isNotValidUser(username)){
      return false;
    }
    sessionStorage.setItem("logeIn","true");
    this.profileHomeRedirect(username);

    return true;
  }

  public closeSession(){
    sessionStorage.removeItem("logeIn");
  }

  private isNotValidUser(username:string):boolean{
  return username!="administrador" && username!="coordinador"
  }

private profileHomeRedirect(username:string):void{

 if(username==="administrador"){
this.router.navigate(["administrador"]);
 }else if( username==="coordinador"){
  this.router.navigate(["coordinador"]);
 }
  }
}
